import './App.css';
import SentimentAnalyzer from './Components/SentimentAnalyzer';
function App() {
  return (
    <div className="App">
      <SentimentAnalyzer/>
    </div>
  );
}
export default App;
