import { useState } from 'react';
import './SentimentAnalyzer.css';
function SentimentAnalyzer() {
  const [text, setText] = useState('');
  const [sentiment, setSentiment] = useState('');
  const [stars, setStars] = useState(0);
  const analyzeSentiment = () => {
    fetch('http://localhost:5000/analyze', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text })
    })
      .then(response => response.json())
      .then(data => {
        const sentiment = data.sentiment;
        setSentiment(sentiment);
        setStars(getStarCount(sentiment));
      })
      .catch(error => console.error('Error:', error));
  };
  const getStarCount = (sentiment) => {
    if (sentiment === 'Positive') return 5;
    if (sentiment === 'Neutral') return 3;
    return 1;
  };
  const renderStars = (n) => {
    var s = '';
    for (let i = 0; i < n; i++) {
      s += '⭐';
    }
    return s;
  };
  return (
    <div className='outer'>
      <div className='main' style={{ padding: '20px', textAlign: 'center' }}>
        <h1>Sentiment Analyzer for Product Review</h1>
        <input
          type="text"
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="Enter text to analyze"
          style={{ width: '300px', padding: '10px', marginBottom: '10px' }}
          required
        />
        <br />
        <button onClick={analyzeSentiment} style={{ padding: '10px 20px', fontSize: '16px' }}>
          Analyze
        </button>
        {sentiment && (
          <div>
            <p className={`sentiment-output ${sentiment}`}>
              Analyzed Sentiment: {sentiment === 'Positive' ? 'Positive' : sentiment === 'Neutral' ? 'Neutral' : 'Negative'}
            </p>
            <p className="stars">Ratings: {renderStars(stars)}</p>
          </div>
        )}
      </div>
    </div>
  );
}
export default SentimentAnalyzer;
