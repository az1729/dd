from flask import Flask, request, jsonify
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
from flask_cors import CORS
app = Flask(__name__)
CORS(app)  
analyzer = SentimentIntensityAnalyzer()
def categorize_sentiment(text):
    scores = analyzer.polarity_scores(text)
    if scores['compound'] >= 0.01:
        return "Positive"
    elif scores['compound'] <= -0.01:
        return "Negative"
    else:
        return "Neutral"
@app.route('/analyze', methods=['POST'])
def analyze_sentiment():
    data = request.json
    text = data.get('text', '')
    sentiment = categorize_sentiment(text)
    return jsonify({'sentiment': sentiment})
if __name__ == '__main__':
    app.run(debug=True)
